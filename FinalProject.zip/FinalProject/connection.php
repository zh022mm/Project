<?php

function get_products(){
	include 'conn.php';
	$query= "SELECT * from products ORDER BY id DESC ";
	if ($result=mysqli_query($conn,$query)) {
		while ($row = $result->fetch_assoc()) {
			echo "Title".$row['title']."<br>";
			echo "discription".$row['discription']."<br>";
			echo "price".$row['price']."<br>";
			echo "image".$row['image']."<br>";
			echo "category".$row['category']."<br>";
		}
	}

}

 ?>
