<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
        
        <title>Home</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/minechik.css" type="text/css">
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




    </head>
    <body>
		<form action="adduser.php" enctype="multipart/form-data" method="post">
		<input type="text" name="username" placeholder="My Name" required>
		<input type="text" name="login" placeholder="Choose nickname" required>
		<input type="password" name="password" required placeholder="New Password">
		<input type="submit" name="registr" value="Registration">
	</form>
		
        
		
		

	<!-- cover -->	
	<div class="service-headder-sign" style="background-image:url(images/photo_1.jpg);">
		</div>
	
		
		<div class="well-sign-in-reg">
				<form name="registration" method="post" action="adduser.php">
				<div class="form-group">
					<label for="name" style="width:auto; color:#FFF056;font-size:30px;text-align:center;border-top-color:#FFF056;">REGISTRATION PANEL</label>
				  </div>
				  
				  <div class="form-group">
					<label style="width:auto; color:white;font-size:16px;">Name: </label>
					<input class="form-control"  name="username" type="text" placeholder="Enter name">
				  </div>
                    
                 <div class="form-group">
					<label style="width:auto; color:white;font-size:16px;">Login: </label>
					<input class="form-control"  name="login" type="text" placeholder="Enter login">
                 </div>
				  
				  <div class="form-group">
					<label style="width:auto; color:white;font-size:16px;">Password: </label>
					<input class="form-control" name="password" type="password" placeholder="Enter password">
				  </div>
                    
				  <div class="form-group"> 
                      <button type="submit"  name="submit" class="btn btn-primary btn-lg">Submit</button>
					</div>
				</form>

        </div>` 
		
    </body>
</html>