<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
        
        <title>Home</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/minechik.css" type="text/css">
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




    </head>
    <body>
		<form action="login.php" enctype="multipart/form-data" method="post">
		<input type="text" name="login" required placeholder="My Login">
		<input type="password" name="password" required placeholder="My Password">
		<input type="submit" name="submit" value="Login" >
	</form>
	<a href="reg.php">Registration</a>

   

	<!-- cover -->	
	<div class="service-headder-sign" style="background-image:url(images/photo_1.jpg);">
		</div>
	
		
		<div class="well-sign-in">
				<form action="login.php" method="POST">
				<div class="form-group">
					<label for="name" style="width:auto; color:#FFF056;font-size:30px;text-align:center;border-top-color:#FFF056;">SIGN-IN</label>
				  </div>
				  
				  <div class="form-group">
					<label style="width:auto; color:white;font-size:16px;">Login</label>
					<input class="form-control"  name="login" type="text" placeholder="Enter login">
				  </div>
				  
				  <div class="form-group">
					<label style="width:auto; color:white;font-size:16px;">Password</label>
					<input class="form-control" name="password" type="password" placeholder="Enter password">
				  </div>
                                    
                  
				  
				  <div class="form-group"> 
                      <button type="submit"  name="submit" class="btn btn-primary btn-lg">Log in</button>
					</div>
				  
                  <div class="form-group">
                      <a href="reg.php" style="width:auto; color:white;font-size:14px;" type="button">Registeration</a>
				  </div>
				</form>

        </div>
		
    </body>
</html>