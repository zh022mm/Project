<?php 
	
	include 'connection.php';
	get_products();
 ?>