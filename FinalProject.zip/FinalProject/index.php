<!DOCTYPE html>
<html lang="en">
	<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/minechik.css" type="text/css">
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




	</head>
	<body>
		<!-- Navigation Bar -->
		<nav class="navbar navbar-inverse">
			<div class="navbar nav-insh">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
						<a class="navbar-brand" href="index.php">OnlineShop.com</a>
					</div>
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li class="active"><a href="index.php">HOME</a></li>
							<li><a href="products.php">PRODUCTS</a></li>
							<li><a href="aboutus.php">ABOUT US</a></li> 
							<li><a href="index1.php">LOGIN</a></li>
							 
						</ul>
					</div>
				</div>
			</div>
		</nav>
		<!-- Navigation Bar -->
	
			
			
		
		
		<div id="myCarousel" class="carousel slide header-carousel" data-ride="carousel" data-interval="3000">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
		  </ol>

		  <!-- Wrapper for slides -->
		  <div class="carousel-inner" role="listbox">
			<div class="item active">
			  <img src="images/ipadpro.jpg">
			 	</div>

			<div class="item">
			  <img src="images/phone.jpg">
			  	</div>

			<div class="item">
			  <img src="images/nout.jpg">
			  	</div>
		  </div>

		  <!-- Left and right controls -->
		  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span aria-hidden="false"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span aria-hidden="false"></span>
			<span class="sr-only">Next</span>
		  </a>
		</div>
		
		<div class="well">
			<form role="form">
			  <div class="form-group">
				<div class="form-group">
				  <label for="email" style="color:white;">What to you want to buy?</label>
				  <select class="form-control" id="sel1">
					<option>Computers</option>
					<option>Phones</option>
					<option>Accsesuares</option>
				  </select>
				</div>
			  </div>
			  
			  <div class="form-group">
					<label for="usr" style="color:white;">Which brand?(Apple/Samsung):</label>
					<input type='text' class="form-control" />
			<div class="form-group">
				<label for="usr" style="color:white;"> Model:</label>
				<input type='text' class="form-control"/>
        </div>
		
			  <div class="form-group">
				  <label for="sel1" style="color:white;">Made in:</label>
				  <select class="form-control" id="sel1">
					<option>USA</option>
					<option> China</option>
					<option>Malaysia</option>
					<option>Kazakhstan</option>
					<option>Turkey</option>
				  </select>
				</div>
			  <button type="submit" class="btn btn-primary btn-lg">Search</button>
			</form>
		</div>
		</div>
		
		
		<!-- Services -->
	    <div class="container">
			<div class="col-lg-12">
				<h2 style=" font-size:50px;">PRODUCTS</h2>
			</div>
			<div class="row" style="padding-bottom:21px;padding-top:21px;">
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/macbook2.jpg" width="140" height="140">
						<h2>COMPUTERS</h2>
							<h5> All new notebook you can find in our site</h5>
			  
				</div>
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/mobile.jpg" width="140" height="140">
						<h2>PHONES</h2>
							<h5>All new smart phones you can find in our site</h5>
			  
				</div>
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/acsses1.jpg" width="140" height="140">
						<h2>ACCSESUARES</h2>
							<h5>All new accsesuares you can find in our site</h5>
			  
				</div>
			</div>
		</div>

	  
	  
	 
		
		 
	
	
		<section style ="background-color:#191919; border-top-style:solid; border-top-width:1px; border-top-color:transparent; padding-top:10px; padding-bottom:10px;">
			<div class="container">
			<div class="col-lg-12 col-lg-offset-2 text-center" style="padding-bottom:10px;">
                    <h5 style="color:white;">All rights are reserved. For web developing</h5>
					</div>
			</div>
		</section>
		
	</body>
</html>
