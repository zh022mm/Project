<?php 
session_start();
include 'conn.php';

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$login = $_POST['login'];
	$password = $_POST['password'];
	$sql = "INSERT INTO users (login, password, name) VALUES ('".$login."', '".$password."', '".$username."' )";
	if (mysqli_query($conn, $sql)) {
		$_SESSION['login'] = $login;
    	header('location: index.php');
	} else {
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}else{
	header('location: reg.php');
}
?>