<?php 
session_start();
include 'conn.php';
if (isset($_POST['submit'])) {
	$login = $_POST['login'];
	$password = $_POST['password'];
	$sql = "SELECT * from users where login=\"$login\" AND password=\"$password\" ";
	$res = mysqli_query($conn, $sql);
	if (mysqli_num_rows($res)>0) {
		$_SESSION['login'] = $login;
		header('location:index.php');
	}
	else{
		header('location:index.php');}
}else{
	header("location:index.php");
}
?>