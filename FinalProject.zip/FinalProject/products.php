<?php
include 'conn.php'; 
$samsung = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=1"));
$samsung_title = $samsung['title'];
$samsung_price = $samsung['price'];
$samsung_discription = $samsung['discription'];

$mac = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=2"));
$mac_title = $mac['title'];
 $mac_price = $mac['price'];
$mac_discription = $mac['discription'];

$GalaxyX = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=3"));
$GalaxyX_title = $GalaxyX['title'];
 $GalaxyX_price = $GalaxyX['price'];
$GalaxyX_discription = $GalaxyX['discription'];

$iphone = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=4"));
$iphone_title = $iphone['title'];
 $iphone_price = $iphone['price'];
$iphone_discription = $iphone['discription'];

$watch = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=5"));
$watch_title = $watch['title']; 
$watch_price = $watch['price'];
$watch_discription = $watch['discription'];

$headphone = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from products where id=6"));
$headphone_title = $headphone['title']; 
$headphone_price = $headphone['price'];
$headphone_discription = $headphone['discription'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Services</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/indes.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>


</head>

<body id="page-top" class="index">

    <!-- Navigation Bar -->
        <nav class="navbar navbar-inverse">
            <div class="navbar nav-insh">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                        <a class="navbar-brand" href="index.php">OnlineShop.com</a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="index.php" class="la">HOME</a></li>
                            <li class="active"><a href="products.php" style="color:" class="la">PRODUCTS</a></li>
                            <li><a href="aboutus.php" class="la">ABOUT US</a></li> 
                            <li><a href="index1.php" class="la">LOGIN</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    

    <!-- Header -->
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro">PRODUCTS</div>
                <div class="intro-2">Meruert ZHUMAN</div>
                <a href="#services" class="intro-2">01EN04d</a>
            </div>
        </div>
    </header>

    <!-- Services Section -->
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Products</h2>
                    <h3 class="text-muted">COMPUTERS</h3>
                </div>
            </div>
            <?php
            echo "<div class='row text-center'>
                <div class='col-md-6'>
                    <h4 class='service-heading'>$mac_title</h4>
                    <br>
                    <img class='im' src='images/macbook1.png'>$mac_discription
                    <br><br>
                    <a class='btn btn-primary btn-lg'>Price:$mac_price</a>
                </div>"?>
                <?php
            echo "<div class='col-md-6'>
                    <h4 class='service-heading'>$samsung_title</h4>
                    <br>
                    <img class='im' src='images/sumsungcomp1.jpg'>$samsung_discription
                    <br><br>
                    <a class='btn btn-primary btn-lg'>Price:$samsung_price</a>
                </div>
            </div>"?>
        </div>
    </section>

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h3 class="text-muted">PHONES</h3>
                </div>
            </div>
            <?php
            echo " <div class='row text-center'>
                <div class='col-md-6'>
                    <h4 class='service-heading'>$iphone_title </h4><br>
                    <img class='im' src='images/iphone6.jpg'>$iphone_discription
                    <br>
                    <a class='btn btn-primary btn-lg'>Price:$iphone_price </a>
                </div>";?>
            <?php
            echo "<div class='col-md-6'>
                    <h4 class='service-heading'>$GalaxyX_title</h4>
                    <br><br>
                    <img class='im' src='images/sumsungphone1.jpg'>$GalaxyX_discription
                    <br><br>
                    <a class='btn btn-primary btn-lg'>Price:$GalaxyX_price</a>
                </div>
            </div>";?>
        </div>
    </section>

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h3 class="text-muted">WATCHES AND HEADPHONES</h3>
                </div>
            </div>
            <?php 
            echo " <div class='row text-center'>
                <div class='col-md-6'>
                    <h4 class='service-heading'>$watch_title</h4><br>
                    <img class='im' src='images/acsses1.jpg'>$watch_discription
                    <br><br>
                    <a class='btn btn-primary btn-lg'>Price:$watch_price</a>
                </div>"; ?>
            <?php 
            echo "<div class='col-md-6'>
                    <h4 class='service-heading'>$headphone_title</h4>
                    <br>
                    <img class='im' src='images/acsses2.jpg'>$headphone_discription
                    <br><br>
                    <a class='btn btn-primary btn-lg'>Price:$headphone_price</a>
                </div>
            </div>  "; ?>
        </div>
    </section>


    <section style ="background-color:#191919; border-top-style:solid; border-top-width:1px; border-top-color:transparent; padding-top:10px; padding-bottom:10px;">
            <div class="container">
            <div class="col-lg-12 col-lg-offset-2 text-center" style="padding-bottom:10px;">
                    <h5 style="color:white;">All rights are reserved. For web developing</h5>
                    </div>
            </div>
        </section>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/agency.js"></script>

</body>

</html>
