<!DOCTYPE html>
<html lang="en">
	<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>About us</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/minechik.css" type="text/css">
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




	</head>
	<body>
		<!-- Navigation Bar -->
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span> 
					</button>
					<a class="navbar-brand" href="index.php">OnlineShop.com</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="index.php">HOME</a></li>
						<li><a href="products.php">PRODUCTS</a></li>
						<li class="active"><a href="aboutus.php">ABOUT US</a></li> 
					</ul>
				</div>
			</div>
		</nav>
		
		

					<!-- SIGN UP Modal -->
			<div id="myModal" class="modal fade" role="dialog">
			  <div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
				  <div class="modal-header">
						<form role="form">
						  <div class="form-group">
							<label for="email">Email address:</label>
							<input type="email" class="form-control" id="email">
						  </div>
						  <div class="form-group">
							<label for="pwd">Password:</label>
							<input type="password" class="form-control" id="pwd">
							<a href="singup.html"><h6>Haven't got login?</h6></a>
						  </div>
						</form>
					</div>
				  <div class="modal-footer">
					<div class="col-sm-offset-2 col-sm-10">
						<button type="submit" class="btn btn-default">Submit</button>
					  </div>
				  </div>
				</div>

			  </div>
			</div>
			
			
		<section class="bg-primary" id="about" style="padding:100px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-lg-offset-2 text-center">
                    <h1 style="white;padding-top:50px">About Author</h1>
                    <hr class="light">
                    <p class="text-faded">This project  made by Meruert Zhuman from 01E04D group.  </p>
                </div>
            </div>
        </div>
    </section>
		
	
	<!-- Services -->
	    <div class="container">
			<div class="col-lg-12">
				<h2 style=" font-size:50px;">PRODUCTS</h2>
			</div>
			<div class="row" style="padding-bottom:21px;padding-top:21px;">
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/macbook2.jpg" width="140" height="140">
						<h2>COMPUTERS</h2>
							<h5> All new notebook you can find in our site</h5>
			  
				</div>
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/mobile.jpg" width="140" height="140">
						<h2>PHONES</h2>
							<h5>All new smart phones you can find in our site</h5>
			  
				</div>
				<div class="col-lg-4">
					<img class="img-circle center-block" src="images/acsses1.jpg" width="140" height="140">
						<h2>ACCSESUARES</h2>
							<h5>All new accsesuares you can find in our site</h5>
			  
				</div>
			</div>
		</div>
	
	
		<section style ="background-color:#191919; border-top-style:solid; border-top-width:1px; border-top-color:transparent; padding-top:10px; padding-bottom:10px;">
			<div class="container">
			<div class="col-lg-12 col-lg-offset-2 text-center" style="padding-bottom:10px;">
                    <h5 style="color:white;">All rights are reserved. For web developing</h5>
					</div>
			</div>
		</section>
	</body>
</html>
